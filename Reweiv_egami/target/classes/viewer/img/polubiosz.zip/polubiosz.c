#include <stdio.h>

extern void polubiosz_encrypt(char input[], int output[]);
 
int main() {
    char *input = "hello";
    int output[5];
    int hossz= 0;
    while(intput[hossz] != 0){
			hossz++;
	}
	if(hossz==0 || hossz>5){
		printf("Hibás bemenet!\n");
		return 0;
	}

    polubiosz_encrypt(input,output);
    for(int i =0 ; i< 5 ; i++){
        printf("'%c' - > %d \n",input[i],output[i] );
    }
    
    
    return 0;
}
